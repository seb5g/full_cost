from pathlib import Path
from django.contrib.auth.decorators import login_required, permission_required
from django.utils.decorators import method_decorator
from lab.views import FilterRecord, ExtractRecord, ShowSetExtraction, Export, GetRecord
from django.shortcuts import render
from .models import Record, Experiment
from .forms import RecordForm, ExtractionForm
from .tables import RecordTable, RecordTableFull, ExtractionTable
from .filters import RecordFilter, ExtractFilter, ExtractDisplayFilter
from full_cost.utils import manage_time
from full_cost.utils.constants import ACTIVITIES
#####################################################
activity_short = Path(__file__).parts[-2]
activity_long = ACTIVITIES[activity_short]['activity_long']
activity={'short': activity_short, 'long': activity_long, 'service': 'Service de FIB',
            'respo_service': 'Robin Cours','activity_short_geslab': ''}
#####################################################

class FilterRecord(FilterRecord):
    filter_class = RecordFilter
    table_class = RecordTable
    activity = activity

@method_decorator(login_required, name='dispatch')
@method_decorator(permission_required(f'{activity_short}.add_extraction', raise_exception=True), name='dispatch')
class ExtractRecord(ExtractRecord):
    filter_class = ExtractFilter
    table_class = RecordTable
    activity = activity



@method_decorator(login_required, name='dispatch')
@method_decorator(permission_required(f'{activity_short}.change_extraction', raise_exception=True), name='dispatch')
class ShowSetExtraction(ShowSetExtraction):
    form_class = ExtractionForm
    filter_class = ExtractDisplayFilter
    table_class = ExtractionTable
    activity = activity

class Export(Export):
    table_class = RecordTableFull
    activity = activity

def load_experiments(request):
    fib = request.GET.get('fib')
    experiments = Experiment.objects.filter(fib_name=fib)
    print(experiments)
    return render(request, 'fib/experiments.html', {'experiments': experiments})


class GetRecord(GetRecord):
    record_class = Record
    form_class = RecordForm
    activity = activity


    def validate_record(self, record, form):
        form = manage_time.check_range_in_range_2_sessions(record, self.record_class, form)
        validate_state = True
        return form, validate_state

    def populate_record(self, data):
        """to be eventually subclassed"""
        # populate a new record
        # billing field should be populated depending on each activity cases (so in subclasses)
        record = self.record_class()
        for key in data:
            if hasattr(self.record_class, key):
                setattr(record, key, data[key])

        return record
