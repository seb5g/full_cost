from django.apps import AppConfig


class FibConfig(AppConfig):
    name = 'fib'
