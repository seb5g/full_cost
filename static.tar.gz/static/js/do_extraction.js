$(document).ready(function() {

    $(".form-control").change(function(){
        $(".form").submit()
    });
});